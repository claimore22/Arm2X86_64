## CASP, CASPA, CASPAL, CASPL

Compare and swap pair of words or doublewords in memory

This instruction reads a pair of 32-bit words or 64-bit doublewords from memory, and compares them against the values held in the first pair of registers. If the comparison is equal, the values in the second pair of registers are written to memory. If the comparison is not equal, the architecture permits writing the value read from the location to memory. If the writes are performed, the reads and writes occur atomically such that no other modification of the memory location can take place between the reads and writes.

- <span class="asm-code">CASPA</span> and <span class="asm-code">CASPAL</span> load from memory with acquire semantics.
- <span class="asm-code">CASPL</span> and <span class="asm-code">CASPAL</span> store to memory with release semantics.
- <span class="asm-code">CASP</span> has neither acquire nor release semantics.

The architecture permits that the data read clears any exclusive monitors associated with that location, even if the compare subsequently fails.

If the instruction generates a synchronous Data Abort, the registers which are compared and loaded, that is \<Ws\> and \<W(s+1)\>, or \<Xs\> and \<X(s+1)\>, are restored to the values held in the registers before the instruction was executed.

For a <span class="asm-code">CASP</span> or <span class="asm-code">CASPA</span> instruction, when \<Ws\> or \<Xs\> specifies the same register as \<Wt\> or \<Xt\>, this signals to the memory system that an additional subsequent <span class="asm-code">CASP</span>, <span class="asm-code">CASPA</span>, <span class="asm-code">CASPAL</span>, or <span class="asm-code">CASPL</span> access to the specified location is expected to occur in the near future in the absence of taking an exception or exceptional software conditions. The memory system can respond by taking actions that are expected to enable the subsequent <span class="asm-code">CASP</span>, <span class="asm-code">CASPA</span>, <span class="asm-code">CASPAL</span>, or <span class="asm-code">CASPL</span> access to succeed when it does occur.

A code sequence starting with a <span class="asm-code">CASP</span> or <span class="asm-code">CASPA</span> instruction for which \<Ws\> or \<Xs\> specifies the same register as \<Wt\> or \<Xt\>, and ending with a subsequent <span class="asm-code">CASP</span>, <span class="asm-code">CASPA</span>, <span class="asm-code">CASPAL</span>, or <span class="asm-code">CASPL</span> to the same location, exhibits the following properties for best performance when the location may be accessed concurrently, on one or more other PEs:

- The sequence does not contain any direct system register writes, address translation instructions, cache or TLB maintenance operations, exception producing instructions, exception returns, or <span class="asm-code">ISB</span> barriers.
- The execution of the sequence includes 32 or fewer instructions.
- The value provided in \<Ws\> or \<Xs\> of the first <span class="asm-code">CASP</span> or <span class="asm-code">CASPA</span> is a value likely to result in the comparison failing. A failing comparison result may lead to better performance due to the hardware not performing a write to memory.

<div class="note">

------------------------------------------------------------------------

#### Note

For a <span class="asm-code">CASP</span> or <span class="asm-code">CASPA</span> instruction, when \<Ws\> or \<Xs\> specifies the same register as \<Wt\> or \<Xt\>, the value in memory is not modified, because the <span class="asm-code">CASP</span> or <span class="asm-code">CASPA</span> either fails its compare or writes the same value back to memory.

For performance reasons, Arm recommends that software not use a <span class="asm-code">CASP</span> or <span class="asm-code">CASPA</span> instruction when \<Ws\> or \<Xs\> specifies the same register as \<Wt\> or \<Xt\> in a routine that includes a subsequent <span class="asm-code">CASP</span>, <span class="asm-code">CASPA</span>, <span class="asm-code">CASPAL</span>, or <span class="asm-code">CASPL</span> for any of the following purposes:

- To load the value that will be compared to conditionally determine whether or not to execute the subsequent <span class="asm-code">CASP</span>, <span class="asm-code">CASPA</span>, <span class="asm-code">CASPAL</span>, or <span class="asm-code">CASPL</span>.
- As a form of prefetch executed between the instruction loading the value that will be compared and the subsequent compare instruction that conditionally determines whether or not to execute the subsequent <span class="asm-code">CASP</span>, <span class="asm-code">CASPA</span>, <span class="asm-code">CASPAL</span>, or <span class="asm-code">CASPL</span>.

This guidance does not apply when \<Ws\> or \<Xs\> specifies the same register as \<Wt\> or \<Xt\> for a <span class="asm-code">CASP</span> or <span class="asm-code">CASPA</span> instruction and the compare between the <span class="asm-code">CASP</span> or <span class="asm-code">CASPA</span> and the subsequent <span class="asm-code">CASP</span>, <span class="asm-code">CASPA</span>, <span class="asm-code">CASPAL</span>, or <span class="asm-code">CASPL</span> is intended to detect an exceptional software condition such that the result of the compare does not prevent the subsequent <span class="asm-code">CASP</span>, <span class="asm-code">CASPA</span>, <span class="asm-code">CASPAL</span>, or <span class="asm-code">CASPL</span> from executing under normal operating conditions.

------------------------------------------------------------------------

</div>

For more information about memory ordering semantics, see <span class="armarm-xref" data-linkend="ARMARM_BEIHCHEF">Load-Acquire, Store-Release</span>.

For information about addressing modes, see <span class="armarm-xref" data-linkend="ARMARM_CHDIIIBB">Load/Store addressing modes</span>.

### <span id="iclass_no_offset"></span>No offset<span style="font-size:smaller;">\
(FEAT_LSE) </span>

<div class="regdiagram-32">

<table class="regdiagram">
<thead>
<tr>
<th>31</th>
<th>30</th>
<th>29</th>
<th>28</th>
<th>27</th>
<th>26</th>
<th>25</th>
<th>24</th>
<th>23</th>
<th>22</th>
<th>21</th>
<th>20</th>
<th>19</th>
<th>18</th>
<th>17</th>
<th>16</th>
<th>15</th>
<th>14</th>
<th>13</th>
<th>12</th>
<th>11</th>
<th>10</th>
<th>9</th>
<th>8</th>
<th>7</th>
<th>6</th>
<th>5</th>
<th>4</th>
<th>3</th>
<th>2</th>
<th>1</th>
<th>0</th>
</tr>
</thead>
<tbody>
<tr class="firstrow">
<td class="lr">0</td>
<td class="lr">sz</td>
<td class="l">0</td>
<td>0</td>
<td>1</td>
<td>0</td>
<td>0</td>
<td>0</td>
<td class="r">0</td>
<td class="lr">L</td>
<td class="lr">1</td>
<td colspan="5" class="lr">Rs</td>
<td class="lr">o0</td>
<td class="l">1</td>
<td>1</td>
<td>1</td>
<td>1</td>
<td class="r">1</td>
<td colspan="5" class="lr">Rn</td>
<td colspan="5" class="lr">Rt</td>
</tr>
<tr class="secondrow">
<td></td>
<td></td>
<td colspan="7"></td>
<td></td>
<td></td>
<td colspan="5"></td>
<td></td>
<td colspan="5" class="droppedname">Rt2</td>
<td colspan="5"></td>
<td colspan="5"></td>
</tr>
</tbody>
</table>

</div>

<div class="encoding">

#### Encoding for the 32-bit CASP variant

<span id="CASP_CP32_comswappr"></span> Applies when <span class="bitdiff"> (sz == 0 && L == 0 && o0 == 0)</span>

CASP [\<Ws\>](#Ws "Is the 32-bit name of the first general-purpose register to be compared and loaded, encoded in the "Rs" field. <Ws> must be an even-numbered register."), [\<W(s+1)\>](#WsPlus1 "Is the 32-bit name of the second general-purpose register to be compared and loaded."), [\<Wt\>](#Wt "Is the 32-bit name of the first general-purpose register to be conditionally stored, encoded in the "Rt" field. <Wt> must be an even-numbered register."), [\<W(t+1)\>](#WtPlus1 "Is the 32-bit name of the second general-purpose register to be conditionally stored."), \[[\<Xn\|SP\>](#XnSP_option "Is the 64-bit name of the general-purpose base register or stack pointer, encoded in the "Rn" field."){, \#0}\]

</div>

<div class="encoding">

#### Encoding for the 32-bit CASPA variant

<span id="CASPA_CP32_comswappr"></span> Applies when <span class="bitdiff"> (sz == 0 && L == 1 && o0 == 0)</span>

CASPA [\<Ws\>](#Ws "Is the 32-bit name of the first general-purpose register to be compared and loaded, encoded in the "Rs" field. <Ws> must be an even-numbered register."), [\<W(s+1)\>](#WsPlus1 "Is the 32-bit name of the second general-purpose register to be compared and loaded."), [\<Wt\>](#Wt "Is the 32-bit name of the first general-purpose register to be conditionally stored, encoded in the "Rt" field. <Wt> must be an even-numbered register."), [\<W(t+1)\>](#WtPlus1 "Is the 32-bit name of the second general-purpose register to be conditionally stored."), \[[\<Xn\|SP\>](#XnSP_option "Is the 64-bit name of the general-purpose base register or stack pointer, encoded in the "Rn" field."){, \#0}\]

</div>

<div class="encoding">

#### Encoding for the 32-bit CASPAL variant

<span id="CASPAL_CP32_comswappr"></span> Applies when <span class="bitdiff"> (sz == 0 && L == 1 && o0 == 1)</span>

CASPAL [\<Ws\>](#Ws "Is the 32-bit name of the first general-purpose register to be compared and loaded, encoded in the "Rs" field. <Ws> must be an even-numbered register."), [\<W(s+1)\>](#WsPlus1 "Is the 32-bit name of the second general-purpose register to be compared and loaded."), [\<Wt\>](#Wt "Is the 32-bit name of the first general-purpose register to be conditionally stored, encoded in the "Rt" field. <Wt> must be an even-numbered register."), [\<W(t+1)\>](#WtPlus1 "Is the 32-bit name of the second general-purpose register to be conditionally stored."), \[[\<Xn\|SP\>](#XnSP_option "Is the 64-bit name of the general-purpose base register or stack pointer, encoded in the "Rn" field."){, \#0}\]

</div>

<div class="encoding">

#### Encoding for the 32-bit CASPL variant

<span id="CASPL_CP32_comswappr"></span> Applies when <span class="bitdiff"> (sz == 0 && L == 0 && o0 == 1)</span>

CASPL [\<Ws\>](#Ws "Is the 32-bit name of the first general-purpose register to be compared and loaded, encoded in the "Rs" field. <Ws> must be an even-numbered register."), [\<W(s+1)\>](#WsPlus1 "Is the 32-bit name of the second general-purpose register to be compared and loaded."), [\<Wt\>](#Wt "Is the 32-bit name of the first general-purpose register to be conditionally stored, encoded in the "Rt" field. <Wt> must be an even-numbered register."), [\<W(t+1)\>](#WtPlus1 "Is the 32-bit name of the second general-purpose register to be conditionally stored."), \[[\<Xn\|SP\>](#XnSP_option "Is the 64-bit name of the general-purpose base register or stack pointer, encoded in the "Rn" field."){, \#0}\]

</div>

<div class="encoding">

#### Encoding for the 64-bit CASP variant

<span id="CASP_CP64_comswappr"></span> Applies when <span class="bitdiff"> (sz == 1 && L == 0 && o0 == 0)</span>

CASP [\<Xs\>](#Xs "Is the 64-bit name of the first general-purpose register to be compared and loaded, encoded in the "Rs" field. <Xs> must be an even-numbered register."), [\<X(s+1)\>](#XsPlus1 "Is the 64-bit name of the second general-purpose register to be compared and loaded."), [\<Xt\>](#Xt "Is the 64-bit name of the first general-purpose register to be conditionally stored, encoded in the "Rt" field. <Xt> must be an even-numbered register."), [\<X(t+1)\>](#XtPlus1__3 "Is the 64-bit name of the second general-purpose register to be conditionally stored."), \[[\<Xn\|SP\>](#XnSP_option "Is the 64-bit name of the general-purpose base register or stack pointer, encoded in the "Rn" field."){, \#0}\]

</div>

<div class="encoding">

#### Encoding for the 64-bit CASPA variant

<span id="CASPA_CP64_comswappr"></span> Applies when <span class="bitdiff"> (sz == 1 && L == 1 && o0 == 0)</span>

CASPA [\<Xs\>](#Xs "Is the 64-bit name of the first general-purpose register to be compared and loaded, encoded in the "Rs" field. <Xs> must be an even-numbered register."), [\<X(s+1)\>](#XsPlus1 "Is the 64-bit name of the second general-purpose register to be compared and loaded."), [\<Xt\>](#Xt "Is the 64-bit name of the first general-purpose register to be conditionally stored, encoded in the "Rt" field. <Xt> must be an even-numbered register."), [\<X(t+1)\>](#XtPlus1__3 "Is the 64-bit name of the second general-purpose register to be conditionally stored."), \[[\<Xn\|SP\>](#XnSP_option "Is the 64-bit name of the general-purpose base register or stack pointer, encoded in the "Rn" field."){, \#0}\]

</div>

<div class="encoding">

#### Encoding for the 64-bit CASPAL variant

<span id="CASPAL_CP64_comswappr"></span> Applies when <span class="bitdiff"> (sz == 1 && L == 1 && o0 == 1)</span>

CASPAL [\<Xs\>](#Xs "Is the 64-bit name of the first general-purpose register to be compared and loaded, encoded in the "Rs" field. <Xs> must be an even-numbered register."), [\<X(s+1)\>](#XsPlus1 "Is the 64-bit name of the second general-purpose register to be compared and loaded."), [\<Xt\>](#Xt "Is the 64-bit name of the first general-purpose register to be conditionally stored, encoded in the "Rt" field. <Xt> must be an even-numbered register."), [\<X(t+1)\>](#XtPlus1__3 "Is the 64-bit name of the second general-purpose register to be conditionally stored."), \[[\<Xn\|SP\>](#XnSP_option "Is the 64-bit name of the general-purpose base register or stack pointer, encoded in the "Rn" field."){, \#0}\]

</div>

<div class="encoding">

#### Encoding for the 64-bit CASPL variant

<span id="CASPL_CP64_comswappr"></span> Applies when <span class="bitdiff"> (sz == 1 && L == 0 && o0 == 1)</span>

CASPL [\<Xs\>](#Xs "Is the 64-bit name of the first general-purpose register to be compared and loaded, encoded in the "Rs" field. <Xs> must be an even-numbered register."), [\<X(s+1)\>](#XsPlus1 "Is the 64-bit name of the second general-purpose register to be compared and loaded."), [\<Xt\>](#Xt "Is the 64-bit name of the first general-purpose register to be conditionally stored, encoded in the "Rt" field. <Xt> must be an even-numbered register."), [\<X(t+1)\>](#XtPlus1__3 "Is the 64-bit name of the second general-purpose register to be conditionally stored."), \[[\<Xn\|SP\>](#XnSP_option "Is the 64-bit name of the general-purpose base register or stack pointer, encoded in the "Rn" field."){, \#0}\]

</div>

#### Decode for all variants of this encoding

if !IsFeatureImplemented(FEAT_LSE) then [EndOfDecode](shared_pseudocode.html#func_EndOfDecode_1)([Decode_UNDEF](shared_pseudocode.html#enum_Decode_UNDEF)); end; if Rs\[0\] == '1' \|\| Rt\[0\] == '1' then [EndOfDecode](shared_pseudocode.html#func_EndOfDecode_1)([Decode_UNDEF](shared_pseudocode.html#enum_Decode_UNDEF)); end; let s : integer{} = UInt(Rs); let t : integer{} = UInt(Rt); let n : integer{} = UInt(Rn); let datasize : integer{} = 32 \<\< UInt(sz); let acquire : boolean = L == '1'; let release : boolean = o0 == '1'; let tagchecked : boolean = n != 31;

<div class="encoding-notes">

</div>

### Assembler Symbols

<div class="explanations">

<table>
<tbody>
<tr>
<td>&lt;Ws&gt;</td>
<td><span id="Ws"></span>
<p>Is the 32-bit name of the first general-purpose register to be compared and loaded, encoded in the "Rs" field. &lt;Ws&gt; must be an even-numbered register.</p></td>
</tr>
</tbody>
</table>

<table>
<tbody>
<tr>
<td>&lt;W(s+1)&gt;</td>
<td><span id="WsPlus1"></span>
<p>Is the 32-bit name of the second general-purpose register to be compared and loaded.</p></td>
</tr>
</tbody>
</table>

<table>
<tbody>
<tr>
<td>&lt;Wt&gt;</td>
<td><span id="Wt"></span>
<p>Is the 32-bit name of the first general-purpose register to be conditionally stored, encoded in the "Rt" field. &lt;Wt&gt; must be an even-numbered register.</p></td>
</tr>
</tbody>
</table>

<table>
<tbody>
<tr>
<td>&lt;W(t+1)&gt;</td>
<td><span id="WtPlus1"></span>
<p>Is the 32-bit name of the second general-purpose register to be conditionally stored.</p></td>
</tr>
</tbody>
</table>

<table>
<tbody>
<tr>
<td>&lt;Xn|SP&gt;</td>
<td><span id="XnSP_option"></span>
<p>Is the 64-bit name of the general-purpose base register or stack pointer, encoded in the "Rn" field.</p></td>
</tr>
</tbody>
</table>

<table>
<tbody>
<tr>
<td>&lt;Xs&gt;</td>
<td><span id="Xs"></span>
<p>Is the 64-bit name of the first general-purpose register to be compared and loaded, encoded in the "Rs" field. &lt;Xs&gt; must be an even-numbered register.</p></td>
</tr>
</tbody>
</table>

<table>
<tbody>
<tr>
<td>&lt;X(s+1)&gt;</td>
<td><span id="XsPlus1"></span>
<p>Is the 64-bit name of the second general-purpose register to be compared and loaded.</p></td>
</tr>
</tbody>
</table>

<table>
<tbody>
<tr>
<td>&lt;Xt&gt;</td>
<td><span id="Xt"></span>
<p>Is the 64-bit name of the first general-purpose register to be conditionally stored, encoded in the "Rt" field. &lt;Xt&gt; must be an even-numbered register.</p></td>
</tr>
</tbody>
</table>

<table>
<tbody>
<tr>
<td>&lt;X(t+1)&gt;</td>
<td><span id="XtPlus1__3"></span>
<p>Is the 64-bit name of the second general-purpose register to be conditionally stored.</p></td>
</tr>
</tbody>
</table>

</div>

<div class="syntax-notes">

</div>

<div class="ps">

### Operation

var address : bits(64); var comparevalue : bits(2\*datasize); var newvalue : bits(2\*datasize); var data : bits(2\*datasize); let s1 : bits(datasize) = X{}(s); let s2 : bits(datasize) = X{}(s+1); let t1 : bits(datasize) = X{}(t); let t2 : bits(datasize) = X{}(t+1); let privileged : boolean = [PSTATE](shared_pseudocode.html#global_PSTATE).EL != [EL0](shared_pseudocode.html#global_EL0); let accdesc : [AccessDescriptor](shared_pseudocode.html#type_AccessDescriptor) = [CreateAccDescAtomicOp](shared_pseudocode.html#func_CreateAccDescAtomicOp_9)([MemAtomicOp_CAS](shared_pseudocode.html#enum_MemAtomicOp_CAS), acquire, release, tagchecked, privileged, t, t+1, s, s+1); comparevalue = if [BigEndian](shared_pseudocode.html#func_BigEndian_1)(accdesc.acctype) then s1::s2 else s2::s1; newvalue = if [BigEndian](shared_pseudocode.html#func_BigEndian_1)(accdesc.acctype) then t1::t2 else t2::t1; if n == 31 then [CheckSPAlignment](shared_pseudocode.html#func_CheckSPAlignment_0)(); address = [SP](shared_pseudocode.html#accessor_SP_1){64}(); else address = [X](shared_pseudocode.html#accessor_X_2){64}(n); end; data = [MemAtomic](shared_pseudocode.html#func_MemAtomic_5){2\*datasize}(address, comparevalue, newvalue, accdesc); if [BigEndian](shared_pseudocode.html#func_BigEndian_1)(accdesc.acctype) then [X](shared_pseudocode.html#accessor_X_2){datasize}(s) = data\[2\*datasize-1:datasize\]; [X](shared_pseudocode.html#accessor_X_2){datasize}(s+1) = data\[datasize-1:0\]; else [X](shared_pseudocode.html#accessor_X_2){datasize}(s) = data\[datasize-1:0\]; [X](shared_pseudocode.html#accessor_X_2){datasize}(s+1) = data\[2\*datasize-1:datasize\]; end;

</div>
